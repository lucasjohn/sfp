package br.com.jl.service.api;
import br.com.jl.model.Responsable;
import org.springframework.roo.addon.layers.service.annotations.RooService;

/**
 * = ResponsableService
 *
 * TODO Auto-generated class documentation
 *
 */
@RooService(entity = Responsable.class)
public interface ResponsableService {
}
