package br.com.jl.repository;
import br.com.jl.model.Responsable;
import org.springframework.roo.addon.layers.repository.jpa.annotations.RooJpaRepositoryCustom;

/**
 * = ResponsableRepositoryCustom
 *
 * TODO Auto-generated class documentation
 *
 */
@RooJpaRepositoryCustom(entity = Responsable.class)
public interface ResponsableRepositoryCustom {
}
