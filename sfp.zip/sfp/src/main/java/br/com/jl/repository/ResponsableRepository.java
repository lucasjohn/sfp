package br.com.jl.repository;
import br.com.jl.model.Responsable;
import org.springframework.roo.addon.layers.repository.jpa.annotations.RooJpaRepository;
import org.springframework.roo.addon.layers.repository.jpa.annotations.finder.RooFinder;

/**
 * = ResponsableRepository
 *
 * TODO Auto-generated class documentation
 *
 */
@RooJpaRepository(entity = Responsable.class, finders = { @RooFinder(value = "findByNameContainsIgnoringCaseOrderByNameAsc", returnType = Responsable.class), @RooFinder(value = "findByCpfEquals", returnType = Responsable.class), @RooFinder(value = "findByEmailContainsIgnoringCaseOrderByNameAsc", returnType = Responsable.class) })
public interface ResponsableRepository {
}
