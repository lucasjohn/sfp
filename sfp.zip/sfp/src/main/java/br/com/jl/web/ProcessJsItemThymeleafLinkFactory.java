package br.com.jl.web;
import org.springframework.roo.addon.web.mvc.thymeleaf.annotations.RooLinkFactory;

/**
 * = ProcessJsItemThymeleafLinkFactory
 *
 * TODO Auto-generated class documentation
 *
 */
@RooLinkFactory(controller = ProcessJsItemThymeleafController.class)
public class ProcessJsItemThymeleafLinkFactory {
}
