package br.com.jl.repository;

import io.springlets.data.jpa.repository.support.QueryDslRepositorySupportExt;
import org.springframework.roo.addon.layers.repository.jpa.annotations.RooJpaRepositoryCustomImpl;
import br.com.jl.model.ProcessJ;

/**
 * = ProcessJRepositoryImpl
 *
 * TODO Auto-generated class documentation
 *
 */ 
@RooJpaRepositoryCustomImpl(repository = ProcessJRepositoryCustom.class)
public class ProcessJRepositoryImpl extends QueryDslRepositorySupportExt<ProcessJ> {

    /**
     * TODO Auto-generated constructor documentation
     */
    ProcessJRepositoryImpl() {
        super(ProcessJ.class);
    }
}