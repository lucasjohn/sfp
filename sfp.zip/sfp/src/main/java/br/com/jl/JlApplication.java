package br.com.jl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * = JlApplication
 *
 * TODO Auto-generated class documentation
 *
 */
@SpringBootApplication
public class JlApplication {

    /**
     * TODO Auto-generated method documentation
     *
     * @param args
     */
    public static void main(String[] args) {
        SpringApplication.run(JlApplication.class, args);
    }
}