package br.com.jl.service.impl;
import br.com.jl.service.api.ProcessJService;
import org.springframework.roo.addon.layers.service.annotations.RooServiceImpl;

/**
 * = ProcessJServiceImpl
 *
 * TODO Auto-generated class documentation
 *
 */
@RooServiceImpl(service = ProcessJService.class)
public class ProcessJServiceImpl implements ProcessJService {
}
