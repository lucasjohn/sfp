package br.com.jl.web;
import org.springframework.roo.addon.web.mvc.thymeleaf.annotations.RooLinkFactory;

/**
 * = ResponsablesCollectionThymeleafLinkFactory
 *
 * TODO Auto-generated class documentation
 *
 */
@RooLinkFactory(controller = ResponsablesCollectionThymeleafController.class)
public class ResponsablesCollectionThymeleafLinkFactory {
}
