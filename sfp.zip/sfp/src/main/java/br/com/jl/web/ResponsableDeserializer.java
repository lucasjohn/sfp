package br.com.jl.web;
import br.com.jl.model.Responsable;
import br.com.jl.service.api.ResponsableService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jackson.JsonObjectDeserializer;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.convert.ConversionService;
import org.springframework.roo.addon.web.mvc.controller.annotations.config.RooDeserializer;

/**
 * = ResponsableDeserializer
 *
 * TODO Auto-generated class documentation
 *
 */
@RooDeserializer(entity = Responsable.class)
public class ResponsableDeserializer extends JsonObjectDeserializer<Responsable> {

    /**
     * TODO Auto-generated attribute documentation
     *
     */
    private ResponsableService responsableService;

    /**
     * TODO Auto-generated attribute documentation
     *
     */
    private ConversionService conversionService;

    /**
     * TODO Auto-generated constructor documentation
     *
     * @param responsableService
     * @param conversionService
     */
    @Autowired
    public ResponsableDeserializer(@Lazy ResponsableService responsableService, ConversionService conversionService) {
        this.responsableService = responsableService;
        this.conversionService = conversionService;
    }
}
