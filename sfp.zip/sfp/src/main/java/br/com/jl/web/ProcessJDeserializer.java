package br.com.jl.web;
import br.com.jl.model.ProcessJ;
import br.com.jl.service.api.ProcessJService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jackson.JsonObjectDeserializer;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.convert.ConversionService;
import org.springframework.roo.addon.web.mvc.controller.annotations.config.RooDeserializer;

/**
 * = ProcessJDeserializer
 *
 * TODO Auto-generated class documentation
 *
 */
@RooDeserializer(entity = ProcessJ.class)
public class ProcessJDeserializer extends JsonObjectDeserializer<ProcessJ> {

    /**
     * TODO Auto-generated attribute documentation
     *
     */
    private ProcessJService processJService;

    /**
     * TODO Auto-generated attribute documentation
     *
     */
    private ConversionService conversionService;

    /**
     * TODO Auto-generated constructor documentation
     *
     * @param processJService
     * @param conversionService
     */
    @Autowired
    public ProcessJDeserializer(@Lazy ProcessJService processJService, ConversionService conversionService) {
        this.processJService = processJService;
        this.conversionService = conversionService;
    }
}
