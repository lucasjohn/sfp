package br.com.jl.model;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.roo.addon.javabean.annotations.RooEquals;
import org.springframework.roo.addon.javabean.annotations.RooJavaBean;
import org.springframework.roo.addon.javabean.annotations.RooToString;
import org.springframework.roo.addon.jpa.annotations.entity.JpaRelationType;
import org.springframework.roo.addon.jpa.annotations.entity.RooJpaEntity;
import org.springframework.roo.addon.jpa.annotations.entity.RooJpaRelation;
import br.com.jl.Situacao;
import javax.persistence.OneToMany;

/**
 * = ProcessJ
 *
 * TODO Auto-generated class documentation
 *
 */
@RooJavaBean
@RooToString
@RooJpaEntity
@RooEquals(isJpaEntity = true)
public class ProcessJ {

    /**
     * TODO Auto-generated attribute documentation
     *
     */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    /**
     * TODO Auto-generated attribute documentation
     *
     */
    @Version
    private Integer version;

    /**
     * TODO Auto-generated attribute documentation
     *
     */
    @NotNull
    @Column(unique = true)
    @Size(min = 20, max = 20)
    private String unifiedProcessNumber;

    /**
     * TODO Auto-generated attribute documentation
     *
     */
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(style = "M-")
    private Calendar distributionDate;

    /**
     * TODO Auto-generated attribute documentation
     *
     */
    @Size(max = 50)
    private String fisicalFolder;

    /**
     * TODO Auto-generated attribute documentation
     *
     */
    @NotNull
    @Enumerated(EnumType.STRING)
    private Situacao situation;

    /**
     * TODO Auto-generated attribute documentation
     *
     */
    @Size(min = 20, max = 20)
    private String fatherProcess;

    /**
     * TODO Auto-generated attribute documentation
     *
     */
    @Size(max = 1000)
    private String description;

    /**
     * TODO Auto-generated attribute documentation
     *
     */
    @NotNull
    @Size(max = 3)
    @OneToMany(cascade = { javax.persistence.CascadeType.MERGE, javax.persistence.CascadeType.PERSIST }, fetch = FetchType.LAZY, mappedBy = "process")
    @RooJpaRelation(type = JpaRelationType.AGGREGATION)
    private Set<Responsable> reponsibleGroup = new HashSet<Responsable>();
}
