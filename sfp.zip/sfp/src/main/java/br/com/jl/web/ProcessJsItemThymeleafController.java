package br.com.jl.web;
import br.com.jl.model.ProcessJ;
import org.springframework.roo.addon.web.mvc.controller.annotations.ControllerType;
import org.springframework.roo.addon.web.mvc.controller.annotations.RooController;
import org.springframework.roo.addon.web.mvc.thymeleaf.annotations.RooThymeleaf;

/**
 * = ProcessJsItemThymeleafController
 *
 * TODO Auto-generated class documentation
 *
 */
@RooController(entity = ProcessJ.class, type = ControllerType.ITEM)
@RooThymeleaf
public class ProcessJsItemThymeleafController {
}
