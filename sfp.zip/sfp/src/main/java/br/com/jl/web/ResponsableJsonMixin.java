package br.com.jl.web;
import br.com.jl.model.Responsable;
import org.springframework.roo.addon.web.mvc.controller.annotations.config.RooJsonMixin;

/**
 * = ResponsableJsonMixin
 *
 * TODO Auto-generated class documentation
 *
 */
@RooJsonMixin(entity = Responsable.class)
public abstract class ResponsableJsonMixin {
}
