package br.com.jl.repository;
import br.com.jl.model.ProcessJ;
import org.springframework.roo.addon.layers.repository.jpa.annotations.RooJpaRepository;
import org.springframework.roo.addon.layers.repository.jpa.annotations.finder.RooFinder;

/**
 * = ProcessJRepository
 *
 * TODO Auto-generated class documentation
 *
 */
@RooJpaRepository(entity = ProcessJ.class, finders = { @RooFinder(value = "findByUnifiedProcessNumberOrDistributionDateBetweenOrSituationOrFisicalFolderOrderByDistributionDateDesc", returnType = ProcessJ.class) })
public interface ProcessJRepository {
}
