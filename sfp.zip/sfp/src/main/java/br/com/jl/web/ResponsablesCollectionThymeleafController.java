package br.com.jl.web;
import br.com.jl.model.Responsable;
import org.springframework.roo.addon.web.mvc.controller.annotations.ControllerType;
import org.springframework.roo.addon.web.mvc.controller.annotations.RooController;
import org.springframework.roo.addon.web.mvc.thymeleaf.annotations.RooThymeleaf;

/**
 * = ResponsablesCollectionThymeleafController
 *
 * TODO Auto-generated class documentation
 *
 */
@RooController(entity = Responsable.class, type = ControllerType.COLLECTION)
@RooThymeleaf
public class ResponsablesCollectionThymeleafController {
}
