package br.com.jl.web;
import br.com.jl.model.ProcessJ;
import org.springframework.roo.addon.web.mvc.controller.annotations.ControllerType;
import org.springframework.roo.addon.web.mvc.controller.annotations.RooController;
import org.springframework.roo.addon.web.mvc.controller.annotations.responses.json.RooJSON;

/**
 * = ProcessJsCollectionJsonController
 *
 * TODO Auto-generated class documentation
 *
 */
@RooController(entity = ProcessJ.class, pathPrefix = "/api", type = ControllerType.COLLECTION)
@RooJSON
public class ProcessJsCollectionJsonController {
}
