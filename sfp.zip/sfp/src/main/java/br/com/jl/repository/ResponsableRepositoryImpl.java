package br.com.jl.repository;

import io.springlets.data.jpa.repository.support.QueryDslRepositorySupportExt;
import org.springframework.roo.addon.layers.repository.jpa.annotations.RooJpaRepositoryCustomImpl;
import br.com.jl.model.Responsable;

/**
 * = ResponsableRepositoryImpl
 *
 * TODO Auto-generated class documentation
 *
 */ 
@RooJpaRepositoryCustomImpl(repository = ResponsableRepositoryCustom.class)
public class ResponsableRepositoryImpl extends QueryDslRepositorySupportExt<Responsable> {

    /**
     * TODO Auto-generated constructor documentation
     */
    ResponsableRepositoryImpl() {
        super(Responsable.class);
    }
}