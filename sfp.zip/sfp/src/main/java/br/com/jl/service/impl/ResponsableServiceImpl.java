package br.com.jl.service.impl;
import br.com.jl.service.api.ResponsableService;
import org.springframework.roo.addon.layers.service.annotations.RooServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;

/**
 * = ResponsableServiceImpl
 *
 * TODO Auto-generated class documentation
 *
 */
@RooServiceImpl(service = ResponsableService.class)
public class ResponsableServiceImpl implements ResponsableService {

    /**
     * TODO Auto-generated attribute documentation
     *
     */
    @Autowired
    private JavaMailSender mailSender;
}
