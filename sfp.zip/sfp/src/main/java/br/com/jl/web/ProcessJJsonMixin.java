package br.com.jl.web;
import br.com.jl.model.ProcessJ;
import org.springframework.roo.addon.web.mvc.controller.annotations.config.RooJsonMixin;

/**
 * = ProcessJJsonMixin
 *
 * TODO Auto-generated class documentation
 *
 */
@RooJsonMixin(entity = ProcessJ.class)
public abstract class ProcessJJsonMixin {
}
