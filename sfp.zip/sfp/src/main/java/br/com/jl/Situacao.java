package br.com.jl;

/**
 * = Situacao
 *
 * TODO Auto-generated class documentation
 *
 */
public enum Situacao {

    EMANDAMENTO, DESMEMBRADO, EMRECURSO, FINALIZADO, ARQUIVADO
}
