package br.com.jl.repository;
import br.com.jl.model.ProcessJ;
import org.springframework.roo.addon.layers.repository.jpa.annotations.RooJpaRepositoryCustom;

/**
 * = ProcessJRepositoryCustom
 *
 * TODO Auto-generated class documentation
 *
 */
@RooJpaRepositoryCustom(entity = ProcessJ.class)
public interface ProcessJRepositoryCustom {
}
