package br.com.jl.web;
import br.com.jl.model.Responsable;
import org.springframework.roo.addon.web.mvc.controller.annotations.ControllerType;
import org.springframework.roo.addon.web.mvc.controller.annotations.RooController;
import org.springframework.roo.addon.web.mvc.controller.annotations.responses.json.RooJSON;

/**
 * = ResponsablesItemJsonController
 *
 * TODO Auto-generated class documentation
 *
 */
@RooController(entity = Responsable.class, pathPrefix = "/api", type = ControllerType.ITEM)
@RooJSON
public class ResponsablesItemJsonController {
}
