package br.com.jl.web;
import org.springframework.roo.addon.web.mvc.thymeleaf.annotations.RooLinkFactory;

/**
 * = ProcessJsCollectionThymeleafLinkFactory
 *
 * TODO Auto-generated class documentation
 *
 */
@RooLinkFactory(controller = ProcessJsCollectionThymeleafController.class)
public class ProcessJsCollectionThymeleafLinkFactory {
}
