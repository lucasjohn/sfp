package br.com.jl.service.api;
import br.com.jl.model.ProcessJ;
import org.springframework.roo.addon.layers.service.annotations.RooService;

/**
 * = ProcessJService
 *
 * TODO Auto-generated class documentation
 *
 */
@RooService(entity = ProcessJ.class)
public interface ProcessJService {
}
