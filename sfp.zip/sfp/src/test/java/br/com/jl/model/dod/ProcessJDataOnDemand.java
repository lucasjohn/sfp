package br.com.jl.model.dod;
import br.com.jl.model.ProcessJ;
import org.springframework.roo.addon.jpa.annotations.dod.RooJpaDataOnDemand;

/**
 * = ProcessJDataOnDemand
 *
 * TODO Auto-generated class documentation
 *
 */
@RooJpaDataOnDemand(entity = ProcessJ.class)
public class ProcessJDataOnDemand {
}
