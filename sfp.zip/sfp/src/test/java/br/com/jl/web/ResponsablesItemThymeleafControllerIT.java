package br.com.jl.web;
import org.springframework.roo.addon.web.mvc.thymeleaf.annotations.test.RooThymeleafControllerIntegrationTest;

/**
 * = ResponsablesItemThymeleafControllerIT
 *
 * TODO Auto-generated class documentation
 *
 */
@RooThymeleafControllerIntegrationTest(targetClass = ResponsablesItemThymeleafController.class)
public class ResponsablesItemThymeleafControllerIT {
}
