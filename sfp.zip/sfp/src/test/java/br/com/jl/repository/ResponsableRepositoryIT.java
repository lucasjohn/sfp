package br.com.jl.repository;
import br.com.jl.dod.DataOnDemandConfiguration;
import br.com.jl.model.dod.ResponsableDataOnDemand;
import org.springframework.roo.addon.layers.repository.jpa.annotations.test.RooRepositoryJpaIntegrationTest;

/**
 * = ResponsableRepositoryIT
 *
 * TODO Auto-generated class documentation
 *
 */
@RooRepositoryJpaIntegrationTest(targetClass = ResponsableRepository.class, dodConfigurationClass = DataOnDemandConfiguration.class, dodClass = ResponsableDataOnDemand.class)
public class ResponsableRepositoryIT {
}
