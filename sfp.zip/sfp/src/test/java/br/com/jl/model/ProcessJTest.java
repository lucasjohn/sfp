package br.com.jl.model;
import org.springframework.roo.addon.jpa.annotations.test.RooJpaUnitTest;

/**
 * = ProcessJTest
 *
 * TODO Auto-generated class documentation
 *
 */
@RooJpaUnitTest(targetClass = ProcessJ.class)
public class ProcessJTest {
}
