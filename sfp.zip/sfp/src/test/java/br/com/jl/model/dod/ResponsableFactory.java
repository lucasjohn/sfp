package br.com.jl.model.dod;
import br.com.jl.model.Responsable;
import org.springframework.roo.addon.jpa.annotations.entity.factory.RooJpaEntityFactory;

/**
 * = ResponsableFactory
 *
 * TODO Auto-generated class documentation
 *
 */
@RooJpaEntityFactory(entity = Responsable.class)
public class ResponsableFactory {
}
