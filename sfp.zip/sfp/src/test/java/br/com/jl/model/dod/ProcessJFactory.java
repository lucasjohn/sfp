package br.com.jl.model.dod;
import br.com.jl.model.ProcessJ;
import org.springframework.roo.addon.jpa.annotations.entity.factory.RooJpaEntityFactory;

/**
 * = ProcessJFactory
 *
 * TODO Auto-generated class documentation
 *
 */
@RooJpaEntityFactory(entity = ProcessJ.class)
public class ProcessJFactory {
}
