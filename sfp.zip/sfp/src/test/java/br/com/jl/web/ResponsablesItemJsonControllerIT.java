package br.com.jl.web;
import org.springframework.roo.addon.web.mvc.controller.annotations.test.RooJsonControllerIntegrationTest;

/**
 * = ResponsablesItemJsonControllerIT
 *
 * TODO Auto-generated class documentation
 *
 */
@RooJsonControllerIntegrationTest(targetClass = ResponsablesItemJsonController.class)
public class ResponsablesItemJsonControllerIT {
}
