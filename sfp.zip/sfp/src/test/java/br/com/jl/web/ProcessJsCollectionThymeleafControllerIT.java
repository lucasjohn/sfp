package br.com.jl.web;
import org.springframework.roo.addon.web.mvc.thymeleaf.annotations.test.RooThymeleafControllerIntegrationTest;

/**
 * = ProcessJsCollectionThymeleafControllerIT
 *
 * TODO Auto-generated class documentation
 *
 */
@RooThymeleafControllerIntegrationTest(targetClass = ProcessJsCollectionThymeleafController.class)
public class ProcessJsCollectionThymeleafControllerIT {
}
