package br.com.jl.dod;
import org.springframework.roo.addon.jpa.annotations.dod.RooJpaDataOnDemandConfiguration;

/**
 * = DataOnDemandConfiguration
 *
 * TODO Auto-generated class documentation
 *
 */
@RooJpaDataOnDemandConfiguration
public class DataOnDemandConfiguration {
}
