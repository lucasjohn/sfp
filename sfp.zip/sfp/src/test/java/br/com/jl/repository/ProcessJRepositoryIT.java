package br.com.jl.repository;
import br.com.jl.dod.DataOnDemandConfiguration;
import br.com.jl.model.dod.ProcessJDataOnDemand;
import org.springframework.roo.addon.layers.repository.jpa.annotations.test.RooRepositoryJpaIntegrationTest;

/**
 * = ProcessJRepositoryIT
 *
 * TODO Auto-generated class documentation
 *
 */
@RooRepositoryJpaIntegrationTest(targetClass = ProcessJRepository.class, dodConfigurationClass = DataOnDemandConfiguration.class, dodClass = ProcessJDataOnDemand.class)
public class ProcessJRepositoryIT {
}
