package br.com.jl.model.dod;
import br.com.jl.model.Responsable;
import org.springframework.roo.addon.jpa.annotations.dod.RooJpaDataOnDemand;

/**
 * = ResponsableDataOnDemand
 *
 * TODO Auto-generated class documentation
 *
 */
@RooJpaDataOnDemand(entity = Responsable.class)
public class ResponsableDataOnDemand {
}
