package br.com.jl.web;
import org.springframework.roo.addon.web.mvc.thymeleaf.annotations.test.RooThymeleafControllerIntegrationTest;

/**
 * = ProcessJsItemThymeleafControllerIT
 *
 * TODO Auto-generated class documentation
 *
 */
@RooThymeleafControllerIntegrationTest(targetClass = ProcessJsItemThymeleafController.class)
public class ProcessJsItemThymeleafControllerIT {
}
