package br.com.jl.model;
import org.springframework.roo.addon.jpa.annotations.test.RooJpaUnitTest;

/**
 * = ResponsableTest
 *
 * TODO Auto-generated class documentation
 *
 */
@RooJpaUnitTest(targetClass = Responsable.class)
public class ResponsableTest {
}
